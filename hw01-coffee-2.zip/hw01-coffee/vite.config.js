import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  // 發布到 GitHub Pages 時，請確認此名稱與你的 GitHub Repository 名稱一致
  base: 'https://github.com/s25113121-alt/coffee-test',
})
